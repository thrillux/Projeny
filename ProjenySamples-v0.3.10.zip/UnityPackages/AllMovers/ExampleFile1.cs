
// This file is simply added as a placeholder to show how Projeny generates
// the custom visual studio solution.  See documentation for details
public static class ExampleFile1
{
}
